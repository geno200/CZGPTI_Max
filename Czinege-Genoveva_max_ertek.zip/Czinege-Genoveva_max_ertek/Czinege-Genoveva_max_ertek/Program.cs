﻿using System;

namespace Czinege_Genoveva_max_ertek
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Maximum kiválasztás tömbben");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("A tömb elemeinek száma: ");
            int h = Convert.ToInt32(Console.ReadLine());
            Console.Write("Mettől? ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Meddig? ");
            int y = Convert.ToInt32(Console.ReadLine());
            int[] tomb = new int[h];
            Random rnd = new Random();
           
            for (int i = 0; i < tomb.Length; i++)
            {
                if (x < y)
                {
                    tomb[i] = rnd.Next(x, y + 1);
                    Console.Write("{0} ", tomb[i]);
                }

            }
           
            
                int max = tomb[0];

                for (int i = 1; i < tomb.Length; i++)
                {
                    if (tomb[i] > max)
                    {
                        max = tomb[i];

                    }
                }
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nA tömbben lévő legnagyobb elem: {0}.", max);
               
            
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }
       
    }
}
